#include "init_LB2.h"

int main(void)
{
    RCC_Init();
    GPIO_Init();
    TIM3_PWM_Init();

    while (1)
    {
        GPIOA->ODR |= GPIO_ODR_OD0;
        GPIOA->ODR &= ~GPIO_ODR_OD1;

        GPIOA->ODR |= GPIO_ODR_OD4;
        GPIOB->ODR &= ~GPIO_ODR_OD0;

        TIM3->CCR1 = 200;
        TIM3->CCR2 = 200;
    }
}